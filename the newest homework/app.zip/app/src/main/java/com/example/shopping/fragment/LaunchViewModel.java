package com.example.shopping.fragment;

import androidx.lifecycle.ViewModel;

public class LaunchViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}