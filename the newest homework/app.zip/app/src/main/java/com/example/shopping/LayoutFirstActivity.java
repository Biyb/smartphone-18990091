package com.example.shopping;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class LayoutFirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_first);


    }


}