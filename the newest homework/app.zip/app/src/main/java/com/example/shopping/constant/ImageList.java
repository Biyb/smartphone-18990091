package com.example.shopping.constant;

import com.example.shopping.R;

import java.util.ArrayList;

public class ImageList {
    public static ArrayList<Integer> getDefault() {
        ArrayList<Integer> imageList = new ArrayList<Integer>();
        imageList.add(R.drawable.top_1);
        imageList.add(R.drawable.top_2);
        imageList.add(R.drawable.top_3);
        imageList.add(R.drawable.top_4);
        imageList.add(R.drawable.top_5);
        return imageList;
    }
}
