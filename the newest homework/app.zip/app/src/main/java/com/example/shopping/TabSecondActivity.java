package com.example.shopping;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class TabSecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_tab_second);



    }
}