package com.example.shopping.adapter;

public class ImagePagerAdapater {
}
